--
-- PostgreSQL database dump
--

-- Dumped from database version 16.9 (Ubuntu 16.9-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.9 (Ubuntu 16.9-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: additional_value; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.additional_value (
    id uuid NOT NULL,
    name jsonb NOT NULL,
    is_user_entry boolean DEFAULT false NOT NULL,
    is_hidden boolean DEFAULT false NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL
);


ALTER TABLE public.additional_value OWNER TO root;

--
-- Name: admins; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.admins (
    id uuid NOT NULL,
    client_id uuid NOT NULL,
    name text NOT NULL,
    is_inactive boolean DEFAULT false NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL
);


ALTER TABLE public.admins OWNER TO root;

--
-- Name: billable_items; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.billable_items (
    id uuid NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    name text NOT NULL,
    price_details jsonb NOT NULL,
    type text NOT NULL,
    code text,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL
);


ALTER TABLE public.billable_items OWNER TO root;

--
-- Name: billable_items_commissions; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.billable_items_commissions (
    id uuid NOT NULL,
    billable_item_id uuid NOT NULL,
    commission numeric(5,4) NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL
);


ALTER TABLE public.billable_items_commissions OWNER TO root;

--
-- Name: business_industry; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.business_industry (
    id uuid NOT NULL,
    name jsonb NOT NULL,
    is_user_entry boolean DEFAULT false NOT NULL,
    is_hidden boolean DEFAULT false NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL
);


ALTER TABLE public.business_industry OWNER TO root;

--
-- Name: business_model; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.business_model (
    id uuid NOT NULL,
    name jsonb NOT NULL,
    is_user_entry boolean DEFAULT false NOT NULL,
    is_hidden boolean DEFAULT false NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL
);


ALTER TABLE public.business_model OWNER TO root;

--
-- Name: business_registration_type; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.business_registration_type (
    id uuid NOT NULL,
    name jsonb NOT NULL,
    is_user_entry boolean DEFAULT false NOT NULL,
    is_hidden boolean DEFAULT false NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL
);


ALTER TABLE public.business_registration_type OWNER TO root;

--
-- Name: cash_ins; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.cash_ins (
    id uuid NOT NULL,
    raw_message text NOT NULL,
    client_id uuid,
    amount jsonb,
    status text NOT NULL,
    notes text,
    response text,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL
);


ALTER TABLE public.cash_ins OWNER TO root;

--
-- Name: cash_outs; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.cash_outs (
    id uuid NOT NULL,
    client_id uuid NOT NULL,
    amount jsonb NOT NULL,
    description text NOT NULL,
    status text NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL
);


ALTER TABLE public.cash_outs OWNER TO root;

--
-- Name: clients; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.clients (
    id uuid NOT NULL,
    username text NOT NULL,
    password_hash text NOT NULL,
    last_login timestamp without time zone,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL,
    preferred_language text DEFAULT 'En'::text NOT NULL
);


ALTER TABLE public.clients OWNER TO root;

--
-- Name: clients_account_payables; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.clients_account_payables (
    id uuid NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    client_id uuid NOT NULL,
    account_id uuid NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL
);


ALTER TABLE public.clients_account_payables OWNER TO root;

--
-- Name: clients_account_receivables; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.clients_account_receivables (
    id uuid NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    client_id uuid NOT NULL,
    account_id uuid NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL
);


ALTER TABLE public.clients_account_receivables OWNER TO root;

--
-- Name: clients_roles; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.clients_roles (
    id uuid NOT NULL,
    client_id uuid NOT NULL,
    role_id uuid NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL
);


ALTER TABLE public.clients_roles OWNER TO root;

--
-- Name: companies; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.companies (
    id uuid NOT NULL,
    expert_id uuid NOT NULL,
    representative_name text NOT NULL,
    representative_role text NOT NULL,
    representative_phone_calling_code text NOT NULL,
    representative_phone_number text NOT NULL,
    company_name text NOT NULL,
    company_email text NOT NULL,
    company_phone_calling_code text NOT NULL,
    company_phone_number text NOT NULL,
    website_url text,
    linkedin_url text,
    social_media_links jsonb,
    business_offerings_description text NOT NULL,
    business_offerings jsonb NOT NULL,
    vat_number text NOT NULL,
    number_of_employees integer NOT NULL,
    registration_certificate_file_id uuid NOT NULL,
    shareholders jsonb NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL
);


ALTER TABLE public.companies OWNER TO root;

--
-- Name: company_additional_info; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.company_additional_info (
    id uuid NOT NULL,
    company_id uuid NOT NULL,
    business_bio text NOT NULL,
    establishment_year integer NOT NULL,
    hq_country_id uuid NOT NULL,
    business_profile_file_id uuid NOT NULL,
    company_logo_file_id uuid NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL
);


ALTER TABLE public.company_additional_info OWNER TO root;

--
-- Name: company_operation_countries; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.company_operation_countries (
    id uuid NOT NULL,
    company_id uuid NOT NULL,
    country_id uuid NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL
);


ALTER TABLE public.company_operation_countries OWNER TO root;

--
-- Name: company_operation_country_states; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.company_operation_country_states (
    id uuid NOT NULL,
    operation_country_id uuid NOT NULL,
    country_state_id uuid NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL
);


ALTER TABLE public.company_operation_country_states OWNER TO root;

--
-- Name: consultation_requests; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.consultation_requests (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    expert_id uuid NOT NULL,
    start_time timestamp without time zone NOT NULL,
    end_time timestamp without time zone NOT NULL,
    service_request_status text NOT NULL,
    service_request_form jsonb NOT NULL,
    session_url text,
    invoice_item_id uuid NOT NULL,
    slot_id uuid NOT NULL,
    expert_rating_id uuid,
    user_rating_id uuid,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL
);


ALTER TABLE public.consultation_requests OWNER TO root;

--
-- Name: consultation_requests_log; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.consultation_requests_log (
    id uuid NOT NULL,
    request_id uuid NOT NULL,
    user_id uuid NOT NULL,
    expert_id uuid NOT NULL,
    start_time timestamp without time zone NOT NULL,
    end_time timestamp without time zone NOT NULL,
    service_request_status text NOT NULL,
    service_request_form jsonb NOT NULL,
    session_url text,
    invoice_item_id uuid NOT NULL,
    expert_slot_id uuid NOT NULL,
    expert_rating_id uuid,
    user_rating_id uuid,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL
);


ALTER TABLE public.consultation_requests_log OWNER TO root;

--
-- Name: countries; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.countries (
    id uuid NOT NULL,
    code text NOT NULL,
    name jsonb NOT NULL,
    phone_code text[] NOT NULL
);


ALTER TABLE public.countries OWNER TO root;

--
-- Name: country_states; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.country_states (
    id uuid NOT NULL,
    country_id uuid NOT NULL,
    name jsonb NOT NULL
);


ALTER TABLE public.country_states OWNER TO root;

--
-- Name: db_migrations; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.db_migrations (
    id integer NOT NULL,
    name character varying(1000),
    version character varying(128) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    direction text NOT NULL
);


ALTER TABLE public.db_migrations OWNER TO root;

--
-- Name: db_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.db_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.db_migrations_id_seq OWNER TO root;

--
-- Name: db_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.db_migrations_id_seq OWNED BY public.db_migrations.id;


--
-- Name: device_tokens; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.device_tokens (
    id uuid NOT NULL,
    token text NOT NULL,
    client_id uuid NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL
);


ALTER TABLE public.device_tokens OWNER TO root;

--
-- Name: dispatched_predefined_service_request_log; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.dispatched_predefined_service_request_log (
    id uuid NOT NULL,
    dispatched_request_id uuid NOT NULL,
    status text NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text)
);


ALTER TABLE public.dispatched_predefined_service_request_log OWNER TO root;

--
-- Name: dispatched_predefined_service_requests; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.dispatched_predefined_service_requests (
    id uuid NOT NULL,
    request_id uuid NOT NULL,
    expert_id uuid NOT NULL,
    status text NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL
);


ALTER TABLE public.dispatched_predefined_service_requests OWNER TO root;

--
-- Name: expert_payments; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.expert_payments (
    id uuid NOT NULL,
    expert_id uuid NOT NULL,
    invoice_item_id uuid NOT NULL,
    status text NOT NULL,
    details jsonb NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL
);


ALTER TABLE public.expert_payments OWNER TO root;

--
-- Name: expert_predefined_services; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.expert_predefined_services (
    id uuid NOT NULL,
    expert_id uuid NOT NULL,
    predefined_service uuid NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL
);


ALTER TABLE public.expert_predefined_services OWNER TO root;

--
-- Name: expert_sector_specializations; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.expert_sector_specializations (
    id uuid NOT NULL,
    expert_id uuid NOT NULL,
    specialization uuid NOT NULL,
    years_of_experience_min integer,
    years_of_experience_max integer,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL
);


ALTER TABLE public.expert_sector_specializations OWNER TO root;

--
-- Name: expert_thematic_specializations; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.expert_thematic_specializations (
    id uuid NOT NULL,
    expert_id uuid NOT NULL,
    specialization uuid NOT NULL,
    years_of_experience_min integer,
    years_of_experience_max integer,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL
);


ALTER TABLE public.expert_thematic_specializations OWNER TO root;

--
-- Name: experts; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.experts (
    id uuid NOT NULL,
    client_id uuid NOT NULL,
    average_rating double precision,
    registration_status text NOT NULL,
    is_profile_complete boolean NOT NULL,
    rateable_item_id uuid NOT NULL,
    billable_item_id uuid,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL
);


ALTER TABLE public.experts OWNER TO root;

--
-- Name: feedback; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.feedback (
    id uuid NOT NULL,
    client_id uuid NOT NULL,
    form jsonb NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL
);


ALTER TABLE public.feedback OWNER TO root;

--
-- Name: financial_accounts; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.financial_accounts (
    id uuid NOT NULL,
    name text NOT NULL,
    description text NOT NULL,
    type text NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL
);


ALTER TABLE public.financial_accounts OWNER TO root;

--
-- Name: financial_currency_accounts; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.financial_currency_accounts (
    id uuid NOT NULL,
    account_id uuid NOT NULL,
    currency text NOT NULL,
    current_balance numeric(20,3) NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL
);


ALTER TABLE public.financial_currency_accounts OWNER TO root;

--
-- Name: form_templates; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.form_templates (
    id uuid NOT NULL,
    type text NOT NULL,
    template_en jsonb NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    template_ar jsonb DEFAULT '{"entries": []}'::jsonb NOT NULL
);


ALTER TABLE public.form_templates OWNER TO root;

--
-- Name: general_config; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.general_config (
    id uuid NOT NULL,
    operation_config jsonb NOT NULL
);


ALTER TABLE public.general_config OWNER TO root;

--
-- Name: individual_additional_info; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.individual_additional_info (
    id uuid NOT NULL,
    profile_picture_file_id uuid,
    individual_id uuid NOT NULL,
    educational_degree text NOT NULL,
    sme_years_of_experience_min integer NOT NULL,
    sme_years_of_experience_max integer,
    startups_years_of_experience_min integer NOT NULL,
    startups_years_of_experience_max integer,
    sudan_years_of_experience_min integer NOT NULL,
    sudan_years_of_experience_max integer,
    portfolio_file_id uuid,
    consultation_price_per_hour_billable_item_id uuid,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL
);


ALTER TABLE public.individual_additional_info OWNER TO root;

--
-- Name: individual_additional_values; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.individual_additional_values (
    id uuid NOT NULL,
    individual_id uuid NOT NULL,
    additional_value_id uuid NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL
);


ALTER TABLE public.individual_additional_values OWNER TO root;

--
-- Name: individuals; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.individuals (
    id uuid NOT NULL,
    expert_id uuid NOT NULL,
    name text NOT NULL,
    bio text NOT NULL,
    role text NOT NULL,
    phone_calling_code text NOT NULL,
    phone_number text NOT NULL,
    whatsapp_calling_code text NOT NULL,
    whatsapp_number text NOT NULL,
    id_document_type text NOT NULL,
    id_document_file_id uuid NOT NULL,
    is_consultant boolean NOT NULL,
    consultation_services_descriptions text,
    is_mentor boolean NOT NULL,
    mentorship_services_descriptions text,
    cv_file_id uuid NOT NULL,
    "references" jsonb NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL
);


ALTER TABLE public.individuals OWNER TO root;

--
-- Name: individuals_available_time_slots; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.individuals_available_time_slots (
    id uuid NOT NULL,
    individual_id uuid NOT NULL,
    start_time timestamp without time zone NOT NULL,
    end_time timestamp without time zone NOT NULL,
    price_details jsonb NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    status text DEFAULT 'Available'::text NOT NULL
);


ALTER TABLE public.individuals_available_time_slots OWNER TO root;

--
-- Name: internal_financial_accounts; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.internal_financial_accounts (
    id uuid NOT NULL,
    account_id uuid NOT NULL,
    type text NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL
);


ALTER TABLE public.internal_financial_accounts OWNER TO root;

--
-- Name: invoice_items; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.invoice_items (
    id uuid NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    invoice_id uuid NOT NULL,
    name text NOT NULL,
    description text,
    type text NOT NULL,
    payment_details jsonb NOT NULL,
    template_id uuid,
    notes text NOT NULL
);


ALTER TABLE public.invoice_items OWNER TO root;

--
-- Name: invoice_payments; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.invoice_payments (
    id uuid NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL,
    invoice_id uuid NOT NULL,
    notes text NOT NULL,
    payment_date date NOT NULL,
    payment jsonb NOT NULL,
    created_by uuid,
    deleted_by uuid,
    is_refund boolean NOT NULL
);


ALTER TABLE public.invoice_payments OWNER TO root;

--
-- Name: invoices; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.invoices (
    id uuid NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    invoice_prefix text,
    invoice_no integer NOT NULL,
    client_id uuid NOT NULL,
    status text NOT NULL,
    date date NOT NULL,
    notes text NOT NULL,
    totals jsonb
);


ALTER TABLE public.invoices OWNER TO root;

--
-- Name: journal_entries; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.journal_entries (
    id uuid NOT NULL,
    transaction_id uuid NOT NULL,
    currency_account_id uuid NOT NULL,
    amount numeric(20,3) NOT NULL,
    is_debit boolean NOT NULL
);


ALTER TABLE public.journal_entries OWNER TO root;

--
-- Name: journal_transactions; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.journal_transactions (
    id uuid NOT NULL,
    date date DEFAULT CURRENT_DATE NOT NULL,
    amount numeric(20,3) NOT NULL,
    currency text NOT NULL,
    description text NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL
);


ALTER TABLE public.journal_transactions OWNER TO root;

--
-- Name: library_material_categories; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.library_material_categories (
    id uuid NOT NULL,
    name text NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL
);


ALTER TABLE public.library_material_categories OWNER TO root;

--
-- Name: library_materials; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.library_materials (
    id uuid NOT NULL,
    title text NOT NULL,
    author text NOT NULL,
    description text NOT NULL,
    type text NOT NULL,
    category_id uuid NOT NULL,
    billable_item_id uuid NOT NULL,
    file_id uuid NOT NULL,
    is_hidden boolean DEFAULT false NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL
);


ALTER TABLE public.library_materials OWNER TO root;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.notifications (
    id uuid NOT NULL,
    client_to_notify uuid,
    notification_type text NOT NULL,
    notification_channel text NOT NULL,
    content jsonb NOT NULL,
    notification_status text NOT NULL,
    time_to_send timestamp without time zone,
    time_to_live timestamp without time zone,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL
);


ALTER TABLE public.notifications OWNER TO root;

--
-- Name: notifications_logs; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.notifications_logs (
    id uuid NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL,
    client_id uuid,
    notification_id uuid NOT NULL,
    channel text NOT NULL,
    status text NOT NULL,
    event_type text NOT NULL
);


ALTER TABLE public.notifications_logs OWNER TO root;

--
-- Name: predefined_service_packages; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.predefined_service_packages (
    id uuid NOT NULL,
    predefined_service_id uuid NOT NULL,
    name jsonb NOT NULL,
    description jsonb NOT NULL,
    billable_item_id uuid NOT NULL,
    is_recurring boolean NOT NULL,
    recursion_interval_in_days integer,
    request_form_id uuid NOT NULL,
    "order" integer NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL
);


ALTER TABLE public.predefined_service_packages OWNER TO root;

--
-- Name: predefined_service_request_log; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.predefined_service_request_log (
    id uuid NOT NULL,
    request_id uuid NOT NULL,
    expert_id uuid,
    log text NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL
);


ALTER TABLE public.predefined_service_request_log OWNER TO root;

--
-- Name: predefined_service_requests; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.predefined_service_requests (
    id uuid NOT NULL,
    predefined_service_package_id uuid NOT NULL,
    recurring_of uuid,
    user_id uuid NOT NULL,
    expert_id uuid,
    service_request_form jsonb NOT NULL,
    service_request_status text NOT NULL,
    invoice_item_id uuid,
    user_rating_id uuid,
    expert_rating_id uuid,
    is_recurring boolean NOT NULL,
    next_recurrence timestamp without time zone,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL,
    start_time timestamp without time zone
);


ALTER TABLE public.predefined_service_requests OWNER TO root;

--
-- Name: predefined_services; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.predefined_services (
    id uuid NOT NULL,
    name jsonb NOT NULL,
    description jsonb NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    is_pinned boolean DEFAULT false NOT NULL,
    auth jsonb
);


ALTER TABLE public.predefined_services OWNER TO root;

--
-- Name: purchased_library_materials; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.purchased_library_materials (
    id uuid NOT NULL,
    buyer_id uuid NOT NULL,
    material_id uuid NOT NULL,
    invoice_item_id uuid NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL
);


ALTER TABLE public.purchased_library_materials OWNER TO root;

--
-- Name: ratable_items; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.ratable_items (
    id uuid NOT NULL
);


ALTER TABLE public.ratable_items OWNER TO root;

--
-- Name: ratings; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.ratings (
    id uuid NOT NULL,
    client_id uuid NOT NULL,
    rateable_item_id uuid,
    rating double precision,
    feedback_form jsonb,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL
);


ALTER TABLE public.ratings OWNER TO root;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.roles (
    id uuid NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    name text NOT NULL,
    role jsonb NOT NULL
);


ALTER TABLE public.roles OWNER TO root;

--
-- Name: sector_specializations; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.sector_specializations (
    id uuid NOT NULL,
    name jsonb NOT NULL,
    is_user_entry boolean DEFAULT false NOT NULL,
    is_hidden boolean DEFAULT false NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL
);


ALTER TABLE public.sector_specializations OWNER TO root;

--
-- Name: specializations; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.specializations (
    id uuid NOT NULL,
    name jsonb NOT NULL,
    is_user_entry boolean DEFAULT false NOT NULL,
    is_hidden boolean DEFAULT false NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL
);


ALTER TABLE public.specializations OWNER TO root;

--
-- Name: thematic_specializations; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.thematic_specializations (
    id uuid NOT NULL,
    name jsonb NOT NULL,
    is_user_entry boolean DEFAULT false NOT NULL,
    is_hidden boolean DEFAULT false NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL
);


ALTER TABLE public.thematic_specializations OWNER TO root;

--
-- Name: uploaded_files_table; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.uploaded_files_table (
    id uuid NOT NULL,
    file_url text NOT NULL,
    file_name text NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL
);


ALTER TABLE public.uploaded_files_table OWNER TO root;

--
-- Name: user_business_details; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.user_business_details (
    id uuid NOT NULL,
    business_id uuid NOT NULL,
    business_offerings jsonb NOT NULL,
    business_value_proposition text NOT NULL,
    social_media_links jsonb NOT NULL,
    website_url text,
    user_role_id uuid NOT NULL,
    registration_type_id uuid NOT NULL,
    is_operating boolean NOT NULL,
    number_of_employees integer NOT NULL,
    business_stage_id uuid NOT NULL,
    business_logo_file_id uuid,
    is_deleted boolean DEFAULT false NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL,
    business_offering_description text NOT NULL
);


ALTER TABLE public.user_business_details OWNER TO root;

--
-- Name: user_business_industry; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.user_business_industry (
    id uuid NOT NULL,
    business_id uuid NOT NULL,
    industry_id uuid NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL
);


ALTER TABLE public.user_business_industry OWNER TO root;

--
-- Name: user_business_model; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.user_business_model (
    id uuid NOT NULL,
    business_id uuid NOT NULL,
    model_id uuid NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL
);


ALTER TABLE public.user_business_model OWNER TO root;

--
-- Name: user_business_operation_countries; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.user_business_operation_countries (
    id uuid NOT NULL,
    business_id uuid NOT NULL,
    country_id uuid NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL
);


ALTER TABLE public.user_business_operation_countries OWNER TO root;

--
-- Name: user_business_operation_country_states; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.user_business_operation_country_states (
    id uuid NOT NULL,
    operation_country_id uuid NOT NULL,
    country_state_id uuid NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL
);


ALTER TABLE public.user_business_operation_country_states OWNER TO root;

--
-- Name: user_business_registration_type; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.user_business_registration_type (
    id uuid NOT NULL,
    business_id uuid NOT NULL,
    registration_type_id uuid NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL
);


ALTER TABLE public.user_business_registration_type OWNER TO root;

--
-- Name: user_business_roles; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.user_business_roles (
    id uuid NOT NULL,
    name jsonb NOT NULL,
    is_user_entry boolean DEFAULT false NOT NULL,
    is_hidden boolean DEFAULT false NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL
);


ALTER TABLE public.user_business_roles OWNER TO root;

--
-- Name: user_business_stage; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.user_business_stage (
    id uuid NOT NULL,
    name jsonb NOT NULL,
    is_user_entry boolean DEFAULT false NOT NULL,
    is_hidden boolean DEFAULT false NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL
);


ALTER TABLE public.user_business_stage OWNER TO root;

--
-- Name: user_businesses; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.user_businesses (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    is_established boolean NOT NULL,
    business_name text NOT NULL,
    business_registration_number text,
    shareholders jsonb,
    is_deleted boolean DEFAULT false NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL
);


ALTER TABLE public.user_businesses OWNER TO root;

--
-- Name: user_current_work_statuses; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.user_current_work_statuses (
    id uuid NOT NULL,
    name jsonb NOT NULL,
    is_user_entry boolean DEFAULT false NOT NULL,
    is_hidden boolean DEFAULT false NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL
);


ALTER TABLE public.user_current_work_statuses OWNER TO root;

--
-- Name: user_living_location_countries; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.user_living_location_countries (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    country_id uuid NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL
);


ALTER TABLE public.user_living_location_countries OWNER TO root;

--
-- Name: user_living_location_country_states; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.user_living_location_country_states (
    id uuid NOT NULL,
    living_location_country_id uuid NOT NULL,
    country_state_id uuid NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL
);


ALTER TABLE public.user_living_location_country_states OWNER TO root;

--
-- Name: user_profiles; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.user_profiles (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    gender text NOT NULL,
    date_of_birth date NOT NULL,
    current_work_status_id uuid NOT NULL,
    linkedin_url text,
    is_deleted boolean DEFAULT false NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL,
    business_idea text
);


ALTER TABLE public.user_profiles OWNER TO root;

--
-- Name: user_specializations; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.user_specializations (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    specialization_id uuid NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL
);


ALTER TABLE public.user_specializations OWNER TO root;

--
-- Name: users; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    client_id uuid NOT NULL,
    name text NOT NULL,
    phone_calling_code text NOT NULL,
    phone_number text NOT NULL,
    whatsapp_calling_code text NOT NULL,
    whatsapp_number text NOT NULL,
    registration_status text NOT NULL,
    is_profile_complete boolean DEFAULT false NOT NULL,
    is_inactive boolean DEFAULT false NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL
);


ALTER TABLE public.users OWNER TO root;

--
-- Name: verifications; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.verifications (
    id uuid NOT NULL,
    email text NOT NULL,
    email_otp text NOT NULL,
    is_verified boolean NOT NULL,
    client_id uuid,
    created_on timestamp without time zone DEFAULT (CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text) NOT NULL
);


ALTER TABLE public.verifications OWNER TO root;

--
-- Name: db_migrations id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.db_migrations ALTER COLUMN id SET DEFAULT nextval('public.db_migrations_id_seq'::regclass);


--
-- Name: additional_value additional_value_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.additional_value
    ADD CONSTRAINT additional_value_pkey PRIMARY KEY (id);


--
-- Name: admins admins_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT admins_pkey PRIMARY KEY (id);


--
-- Name: billable_items_commissions billable_items_commissions_billable_item_id_unique; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.billable_items_commissions
    ADD CONSTRAINT billable_items_commissions_billable_item_id_unique UNIQUE (billable_item_id);


--
-- Name: billable_items_commissions billable_items_commissions_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.billable_items_commissions
    ADD CONSTRAINT billable_items_commissions_pkey PRIMARY KEY (id);


--
-- Name: billable_items billable_items_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.billable_items
    ADD CONSTRAINT billable_items_pkey PRIMARY KEY (id);


--
-- Name: business_industry business_industry_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.business_industry
    ADD CONSTRAINT business_industry_pkey PRIMARY KEY (id);


--
-- Name: business_model business_model_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.business_model
    ADD CONSTRAINT business_model_pkey PRIMARY KEY (id);


--
-- Name: business_registration_type business_registration_type_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.business_registration_type
    ADD CONSTRAINT business_registration_type_pkey PRIMARY KEY (id);


--
-- Name: cash_ins cash_ins_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.cash_ins
    ADD CONSTRAINT cash_ins_pkey PRIMARY KEY (id);


--
-- Name: cash_outs cash_outs_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.cash_outs
    ADD CONSTRAINT cash_outs_pkey PRIMARY KEY (id);


--
-- Name: clients_account_payables client_wallets_client_id_unique; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.clients_account_payables
    ADD CONSTRAINT client_wallets_client_id_unique UNIQUE (client_id);


--
-- Name: clients_account_payables client_wallets_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.clients_account_payables
    ADD CONSTRAINT client_wallets_pkey PRIMARY KEY (id);


--
-- Name: clients_account_receivables clients_account_receivables_client_id_unique; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.clients_account_receivables
    ADD CONSTRAINT clients_account_receivables_client_id_unique UNIQUE (client_id);


--
-- Name: clients_account_receivables clients_account_receivables_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.clients_account_receivables
    ADD CONSTRAINT clients_account_receivables_pkey PRIMARY KEY (id);


--
-- Name: clients clients_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_pkey PRIMARY KEY (id);


--
-- Name: clients_roles clients_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.clients_roles
    ADD CONSTRAINT clients_roles_pkey PRIMARY KEY (id);


--
-- Name: companies companies_expert_id_unique; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_expert_id_unique UNIQUE (expert_id);


--
-- Name: companies companies_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_pkey PRIMARY KEY (id);


--
-- Name: company_additional_info company_additional_info_company_id_unique; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.company_additional_info
    ADD CONSTRAINT company_additional_info_company_id_unique UNIQUE (company_id);


--
-- Name: company_additional_info company_additional_info_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.company_additional_info
    ADD CONSTRAINT company_additional_info_pkey PRIMARY KEY (id);


--
-- Name: company_operation_countries company_operation_countries_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.company_operation_countries
    ADD CONSTRAINT company_operation_countries_pkey PRIMARY KEY (id);


--
-- Name: company_operation_country_states company_operation_country_states_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.company_operation_country_states
    ADD CONSTRAINT company_operation_country_states_pkey PRIMARY KEY (id);


--
-- Name: expert_predefined_services company_predefined_services_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.expert_predefined_services
    ADD CONSTRAINT company_predefined_services_pkey PRIMARY KEY (id);


--
-- Name: consultation_requests_log consultation_requests_log_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.consultation_requests_log
    ADD CONSTRAINT consultation_requests_log_pkey PRIMARY KEY (id);


--
-- Name: consultation_requests consultation_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.consultation_requests
    ADD CONSTRAINT consultation_requests_pkey PRIMARY KEY (id);


--
-- Name: countries countries_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.countries
    ADD CONSTRAINT countries_pkey PRIMARY KEY (id);


--
-- Name: country_states country_states_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.country_states
    ADD CONSTRAINT country_states_pkey PRIMARY KEY (id);


--
-- Name: db_migrations db_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.db_migrations
    ADD CONSTRAINT db_migrations_pkey PRIMARY KEY (id);


--
-- Name: device_tokens device_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.device_tokens
    ADD CONSTRAINT device_tokens_pkey PRIMARY KEY (id);


--
-- Name: dispatched_predefined_service_request_log dispatched_predefined_service_request_log_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.dispatched_predefined_service_request_log
    ADD CONSTRAINT dispatched_predefined_service_request_log_pkey PRIMARY KEY (id);


--
-- Name: dispatched_predefined_service_requests dispatched_predefined_service_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.dispatched_predefined_service_requests
    ADD CONSTRAINT dispatched_predefined_service_requests_pkey PRIMARY KEY (id);


--
-- Name: expert_payments expert_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.expert_payments
    ADD CONSTRAINT expert_payments_pkey PRIMARY KEY (id);


--
-- Name: expert_sector_specializations expert_sector_specializations_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.expert_sector_specializations
    ADD CONSTRAINT expert_sector_specializations_pkey PRIMARY KEY (id);


--
-- Name: expert_thematic_specializations expert_thematic_specializations_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.expert_thematic_specializations
    ADD CONSTRAINT expert_thematic_specializations_pkey PRIMARY KEY (id);


--
-- Name: experts experts_billable_item_id_unique; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.experts
    ADD CONSTRAINT experts_billable_item_id_unique UNIQUE (billable_item_id);


--
-- Name: experts experts_client_id_unique; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.experts
    ADD CONSTRAINT experts_client_id_unique UNIQUE (client_id);


--
-- Name: experts experts_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.experts
    ADD CONSTRAINT experts_pkey PRIMARY KEY (id);


--
-- Name: feedback feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.feedback
    ADD CONSTRAINT feedback_pkey PRIMARY KEY (id);


--
-- Name: financial_accounts financial_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.financial_accounts
    ADD CONSTRAINT financial_accounts_pkey PRIMARY KEY (id);


--
-- Name: financial_currency_accounts financial_currency_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.financial_currency_accounts
    ADD CONSTRAINT financial_currency_accounts_pkey PRIMARY KEY (id);


--
-- Name: form_templates form_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.form_templates
    ADD CONSTRAINT form_templates_pkey PRIMARY KEY (id);


--
-- Name: general_config general_config_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.general_config
    ADD CONSTRAINT general_config_pkey PRIMARY KEY (id);


--
-- Name: individual_additional_info individual_additional_info_individual_id_unique; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.individual_additional_info
    ADD CONSTRAINT individual_additional_info_individual_id_unique UNIQUE (individual_id);


--
-- Name: individual_additional_info individual_additional_info_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.individual_additional_info
    ADD CONSTRAINT individual_additional_info_pkey PRIMARY KEY (id);


--
-- Name: individual_additional_values individual_additional_values_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.individual_additional_values
    ADD CONSTRAINT individual_additional_values_pkey PRIMARY KEY (id);


--
-- Name: individuals_available_time_slots individuals_available_time_slots_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.individuals_available_time_slots
    ADD CONSTRAINT individuals_available_time_slots_pkey PRIMARY KEY (id);


--
-- Name: individuals individuals_expert_id_unique; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.individuals
    ADD CONSTRAINT individuals_expert_id_unique UNIQUE (expert_id);


--
-- Name: individuals individuals_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.individuals
    ADD CONSTRAINT individuals_pkey PRIMARY KEY (id);


--
-- Name: internal_financial_accounts internal_financial_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.internal_financial_accounts
    ADD CONSTRAINT internal_financial_accounts_pkey PRIMARY KEY (id);


--
-- Name: invoice_items invoice_items_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.invoice_items
    ADD CONSTRAINT invoice_items_pkey PRIMARY KEY (id);


--
-- Name: invoice_payments invoice_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.invoice_payments
    ADD CONSTRAINT invoice_payments_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: journal_entries journal_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT journal_entries_pkey PRIMARY KEY (id);


--
-- Name: journal_transactions journal_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.journal_transactions
    ADD CONSTRAINT journal_transactions_pkey PRIMARY KEY (id);


--
-- Name: library_material_categories library_material_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.library_material_categories
    ADD CONSTRAINT library_material_categories_pkey PRIMARY KEY (id);


--
-- Name: library_materials library_materials_billable_item_id_unique; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.library_materials
    ADD CONSTRAINT library_materials_billable_item_id_unique UNIQUE (billable_item_id);


--
-- Name: library_materials library_materials_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.library_materials
    ADD CONSTRAINT library_materials_pkey PRIMARY KEY (id);


--
-- Name: notifications_logs notifications_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.notifications_logs
    ADD CONSTRAINT notifications_logs_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: predefined_service_packages predefined_service_packages_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.predefined_service_packages
    ADD CONSTRAINT predefined_service_packages_pkey PRIMARY KEY (id);


--
-- Name: predefined_service_request_log predefined_service_request_log_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.predefined_service_request_log
    ADD CONSTRAINT predefined_service_request_log_pkey PRIMARY KEY (id);


--
-- Name: predefined_service_requests predefined_service_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.predefined_service_requests
    ADD CONSTRAINT predefined_service_requests_pkey PRIMARY KEY (id);


--
-- Name: predefined_services predefined_services_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.predefined_services
    ADD CONSTRAINT predefined_services_pkey PRIMARY KEY (id);


--
-- Name: purchased_library_materials purchased_library_materials_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.purchased_library_materials
    ADD CONSTRAINT purchased_library_materials_pkey PRIMARY KEY (id);


--
-- Name: ratable_items ratable_items_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.ratable_items
    ADD CONSTRAINT ratable_items_pkey PRIMARY KEY (id);


--
-- Name: ratings ratings_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.ratings
    ADD CONSTRAINT ratings_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: sector_specializations sector_specializations_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.sector_specializations
    ADD CONSTRAINT sector_specializations_pkey PRIMARY KEY (id);


--
-- Name: specializations specializations_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.specializations
    ADD CONSTRAINT specializations_pkey PRIMARY KEY (id);


--
-- Name: thematic_specializations thematic_specializations_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.thematic_specializations
    ADD CONSTRAINT thematic_specializations_pkey PRIMARY KEY (id);


--
-- Name: uploaded_files_table uploaded_files_table_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.uploaded_files_table
    ADD CONSTRAINT uploaded_files_table_pkey PRIMARY KEY (id);


--
-- Name: user_business_details user_business_details_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.user_business_details
    ADD CONSTRAINT user_business_details_pkey PRIMARY KEY (id);


--
-- Name: user_business_industry user_business_industry_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.user_business_industry
    ADD CONSTRAINT user_business_industry_pkey PRIMARY KEY (id);


--
-- Name: user_business_model user_business_model_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.user_business_model
    ADD CONSTRAINT user_business_model_pkey PRIMARY KEY (id);


--
-- Name: user_business_operation_countries user_business_operation_countries_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.user_business_operation_countries
    ADD CONSTRAINT user_business_operation_countries_pkey PRIMARY KEY (id);


--
-- Name: user_business_operation_country_states user_business_operation_country_states_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.user_business_operation_country_states
    ADD CONSTRAINT user_business_operation_country_states_pkey PRIMARY KEY (id);


--
-- Name: user_business_registration_type user_business_registration_type_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.user_business_registration_type
    ADD CONSTRAINT user_business_registration_type_pkey PRIMARY KEY (id);


--
-- Name: user_business_roles user_business_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.user_business_roles
    ADD CONSTRAINT user_business_roles_pkey PRIMARY KEY (id);


--
-- Name: user_business_stage user_business_stage_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.user_business_stage
    ADD CONSTRAINT user_business_stage_pkey PRIMARY KEY (id);


--
-- Name: user_businesses user_businesses_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.user_businesses
    ADD CONSTRAINT user_businesses_pkey PRIMARY KEY (id);


--
-- Name: user_current_work_statuses user_current_work_statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.user_current_work_statuses
    ADD CONSTRAINT user_current_work_statuses_pkey PRIMARY KEY (id);


--
-- Name: user_living_location_countries user_living_location_countries_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.user_living_location_countries
    ADD CONSTRAINT user_living_location_countries_pkey PRIMARY KEY (id);


--
-- Name: user_living_location_country_states user_living_location_country_states_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.user_living_location_country_states
    ADD CONSTRAINT user_living_location_country_states_pkey PRIMARY KEY (id);


--
-- Name: user_profiles user_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.user_profiles
    ADD CONSTRAINT user_profiles_pkey PRIMARY KEY (id);


--
-- Name: user_profiles user_profiles_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.user_profiles
    ADD CONSTRAINT user_profiles_user_id_unique UNIQUE (user_id);


--
-- Name: user_specializations user_specializations_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.user_specializations
    ADD CONSTRAINT user_specializations_pkey PRIMARY KEY (id);


--
-- Name: users users_client_id_unique; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_client_id_unique UNIQUE (client_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: verifications verifications_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.verifications
    ADD CONSTRAINT verifications_pkey PRIMARY KEY (id);


--
-- Name: clients_username; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX clients_username ON public.clients USING btree (username);


--
-- Name: user_business_details_not_deleted_business_id_unique; Type: INDEX; Schema: public; Owner: root
--

CREATE UNIQUE INDEX user_business_details_not_deleted_business_id_unique ON public.user_business_details USING btree (business_id) WHERE (is_deleted IS FALSE);


--
-- Name: admins fk_admins_client_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT fk_admins_client_id__id FOREIGN KEY (client_id) REFERENCES public.clients(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: billable_items_commissions fk_billable_items_commissions_billable_item_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.billable_items_commissions
    ADD CONSTRAINT fk_billable_items_commissions_billable_item_id__id FOREIGN KEY (billable_item_id) REFERENCES public.billable_items(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: cash_ins fk_cash_ins_client_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.cash_ins
    ADD CONSTRAINT fk_cash_ins_client_id__id FOREIGN KEY (client_id) REFERENCES public.clients(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: cash_outs fk_cash_outs_client_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.cash_outs
    ADD CONSTRAINT fk_cash_outs_client_id__id FOREIGN KEY (client_id) REFERENCES public.clients(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: clients_account_payables fk_client_wallets_account_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.clients_account_payables
    ADD CONSTRAINT fk_client_wallets_account_id__id FOREIGN KEY (account_id) REFERENCES public.financial_accounts(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: clients_account_payables fk_client_wallets_client_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.clients_account_payables
    ADD CONSTRAINT fk_client_wallets_client_id__id FOREIGN KEY (client_id) REFERENCES public.clients(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: clients_account_receivables fk_clients_account_receivables_account_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.clients_account_receivables
    ADD CONSTRAINT fk_clients_account_receivables_account_id__id FOREIGN KEY (account_id) REFERENCES public.financial_accounts(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: clients_account_receivables fk_clients_account_receivables_client_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.clients_account_receivables
    ADD CONSTRAINT fk_clients_account_receivables_client_id__id FOREIGN KEY (client_id) REFERENCES public.clients(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: clients_roles fk_clients_roles_client_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.clients_roles
    ADD CONSTRAINT fk_clients_roles_client_id__id FOREIGN KEY (client_id) REFERENCES public.clients(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: clients_roles fk_clients_roles_role_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.clients_roles
    ADD CONSTRAINT fk_clients_roles_role_id__id FOREIGN KEY (role_id) REFERENCES public.roles(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: companies fk_companies_expert_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT fk_companies_expert_id__id FOREIGN KEY (expert_id) REFERENCES public.experts(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: companies fk_companies_registration_certificate_file_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT fk_companies_registration_certificate_file_id__id FOREIGN KEY (registration_certificate_file_id) REFERENCES public.uploaded_files_table(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: company_additional_info fk_company_additional_info_business_profile_file_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.company_additional_info
    ADD CONSTRAINT fk_company_additional_info_business_profile_file_id__id FOREIGN KEY (business_profile_file_id) REFERENCES public.uploaded_files_table(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: company_additional_info fk_company_additional_info_company_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.company_additional_info
    ADD CONSTRAINT fk_company_additional_info_company_id__id FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: company_additional_info fk_company_additional_info_company_logo_file_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.company_additional_info
    ADD CONSTRAINT fk_company_additional_info_company_logo_file_id__id FOREIGN KEY (company_logo_file_id) REFERENCES public.uploaded_files_table(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: company_additional_info fk_company_additional_info_hq_country_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.company_additional_info
    ADD CONSTRAINT fk_company_additional_info_hq_country_id__id FOREIGN KEY (hq_country_id) REFERENCES public.countries(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: company_operation_countries fk_company_operation_countries_company_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.company_operation_countries
    ADD CONSTRAINT fk_company_operation_countries_company_id__id FOREIGN KEY (company_id) REFERENCES public.companies(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: company_operation_countries fk_company_operation_countries_country_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.company_operation_countries
    ADD CONSTRAINT fk_company_operation_countries_country_id__id FOREIGN KEY (country_id) REFERENCES public.countries(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: company_operation_country_states fk_company_operation_country_states_country_state_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.company_operation_country_states
    ADD CONSTRAINT fk_company_operation_country_states_country_state_id__id FOREIGN KEY (country_state_id) REFERENCES public.country_states(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: company_operation_country_states fk_company_operation_country_states_operation_country_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.company_operation_country_states
    ADD CONSTRAINT fk_company_operation_country_states_operation_country_id__id FOREIGN KEY (operation_country_id) REFERENCES public.company_operation_countries(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: expert_predefined_services fk_company_predefined_services_expert_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.expert_predefined_services
    ADD CONSTRAINT fk_company_predefined_services_expert_id__id FOREIGN KEY (expert_id) REFERENCES public.experts(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: expert_predefined_services fk_company_predefined_services_predefined_service__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.expert_predefined_services
    ADD CONSTRAINT fk_company_predefined_services_predefined_service__id FOREIGN KEY (predefined_service) REFERENCES public.predefined_services(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: consultation_requests fk_consultation_requests_expert_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.consultation_requests
    ADD CONSTRAINT fk_consultation_requests_expert_id__id FOREIGN KEY (expert_id) REFERENCES public.experts(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: consultation_requests fk_consultation_requests_expert_rating_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.consultation_requests
    ADD CONSTRAINT fk_consultation_requests_expert_rating_id__id FOREIGN KEY (expert_rating_id) REFERENCES public.ratings(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: consultation_requests fk_consultation_requests_invoice_item_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.consultation_requests
    ADD CONSTRAINT fk_consultation_requests_invoice_item_id__id FOREIGN KEY (invoice_item_id) REFERENCES public.invoice_items(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: consultation_requests_log fk_consultation_requests_log_expert_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.consultation_requests_log
    ADD CONSTRAINT fk_consultation_requests_log_expert_id__id FOREIGN KEY (expert_id) REFERENCES public.experts(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: consultation_requests_log fk_consultation_requests_log_expert_rating_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.consultation_requests_log
    ADD CONSTRAINT fk_consultation_requests_log_expert_rating_id__id FOREIGN KEY (expert_rating_id) REFERENCES public.ratings(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: consultation_requests_log fk_consultation_requests_log_expert_slot_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.consultation_requests_log
    ADD CONSTRAINT fk_consultation_requests_log_expert_slot_id__id FOREIGN KEY (expert_slot_id) REFERENCES public.individuals_available_time_slots(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: consultation_requests_log fk_consultation_requests_log_invoice_item_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.consultation_requests_log
    ADD CONSTRAINT fk_consultation_requests_log_invoice_item_id__id FOREIGN KEY (invoice_item_id) REFERENCES public.invoice_items(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: consultation_requests_log fk_consultation_requests_log_request_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.consultation_requests_log
    ADD CONSTRAINT fk_consultation_requests_log_request_id__id FOREIGN KEY (request_id) REFERENCES public.consultation_requests(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: consultation_requests_log fk_consultation_requests_log_user_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.consultation_requests_log
    ADD CONSTRAINT fk_consultation_requests_log_user_id__id FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: consultation_requests_log fk_consultation_requests_log_user_rating_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.consultation_requests_log
    ADD CONSTRAINT fk_consultation_requests_log_user_rating_id__id FOREIGN KEY (user_rating_id) REFERENCES public.ratings(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: consultation_requests fk_consultation_requests_slot_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.consultation_requests
    ADD CONSTRAINT fk_consultation_requests_slot_id__id FOREIGN KEY (slot_id) REFERENCES public.individuals_available_time_slots(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: consultation_requests fk_consultation_requests_user_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.consultation_requests
    ADD CONSTRAINT fk_consultation_requests_user_id__id FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: consultation_requests fk_consultation_requests_user_rating_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.consultation_requests
    ADD CONSTRAINT fk_consultation_requests_user_rating_id__id FOREIGN KEY (user_rating_id) REFERENCES public.ratings(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: country_states fk_country_states_country_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.country_states
    ADD CONSTRAINT fk_country_states_country_id__id FOREIGN KEY (country_id) REFERENCES public.countries(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: device_tokens fk_device_tokens_client_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.device_tokens
    ADD CONSTRAINT fk_device_tokens_client_id__id FOREIGN KEY (client_id) REFERENCES public.clients(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: dispatched_predefined_service_request_log fk_dispatched_predefined_service_request_logs_dispatched_reques; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.dispatched_predefined_service_request_log
    ADD CONSTRAINT fk_dispatched_predefined_service_request_logs_dispatched_reques FOREIGN KEY (dispatched_request_id) REFERENCES public.dispatched_predefined_service_requests(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: dispatched_predefined_service_requests fk_dispatched_predefined_service_requests_expert_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.dispatched_predefined_service_requests
    ADD CONSTRAINT fk_dispatched_predefined_service_requests_expert_id__id FOREIGN KEY (expert_id) REFERENCES public.experts(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: dispatched_predefined_service_requests fk_dispatched_predefined_service_requests_request_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.dispatched_predefined_service_requests
    ADD CONSTRAINT fk_dispatched_predefined_service_requests_request_id__id FOREIGN KEY (request_id) REFERENCES public.predefined_service_requests(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: expert_payments fk_expert_payments_expert_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.expert_payments
    ADD CONSTRAINT fk_expert_payments_expert_id__id FOREIGN KEY (expert_id) REFERENCES public.experts(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: expert_payments fk_expert_payments_invoice_item_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.expert_payments
    ADD CONSTRAINT fk_expert_payments_invoice_item_id__id FOREIGN KEY (invoice_item_id) REFERENCES public.invoice_items(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: expert_sector_specializations fk_expert_sector_specializations_expert_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.expert_sector_specializations
    ADD CONSTRAINT fk_expert_sector_specializations_expert_id__id FOREIGN KEY (expert_id) REFERENCES public.experts(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: expert_sector_specializations fk_expert_sector_specializations_specialization__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.expert_sector_specializations
    ADD CONSTRAINT fk_expert_sector_specializations_specialization__id FOREIGN KEY (specialization) REFERENCES public.sector_specializations(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: expert_thematic_specializations fk_expert_thematic_specializations_expert_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.expert_thematic_specializations
    ADD CONSTRAINT fk_expert_thematic_specializations_expert_id__id FOREIGN KEY (expert_id) REFERENCES public.experts(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: expert_thematic_specializations fk_expert_thematic_specializations_specialization__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.expert_thematic_specializations
    ADD CONSTRAINT fk_expert_thematic_specializations_specialization__id FOREIGN KEY (specialization) REFERENCES public.thematic_specializations(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: experts fk_experts_billable_item_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.experts
    ADD CONSTRAINT fk_experts_billable_item_id__id FOREIGN KEY (billable_item_id) REFERENCES public.billable_items(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: experts fk_experts_client_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.experts
    ADD CONSTRAINT fk_experts_client_id__id FOREIGN KEY (client_id) REFERENCES public.clients(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: experts fk_experts_rateable_item_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.experts
    ADD CONSTRAINT fk_experts_rateable_item_id__id FOREIGN KEY (rateable_item_id) REFERENCES public.ratable_items(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: feedback fk_feedback_client_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.feedback
    ADD CONSTRAINT fk_feedback_client_id__id FOREIGN KEY (client_id) REFERENCES public.clients(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: financial_currency_accounts fk_financial_currency_accounts_account_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.financial_currency_accounts
    ADD CONSTRAINT fk_financial_currency_accounts_account_id__id FOREIGN KEY (account_id) REFERENCES public.financial_accounts(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: individual_additional_info fk_individual_additional_info_consultation_price_per_hour_billa; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.individual_additional_info
    ADD CONSTRAINT fk_individual_additional_info_consultation_price_per_hour_billa FOREIGN KEY (consultation_price_per_hour_billable_item_id) REFERENCES public.billable_items(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: individual_additional_info fk_individual_additional_info_individual_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.individual_additional_info
    ADD CONSTRAINT fk_individual_additional_info_individual_id__id FOREIGN KEY (individual_id) REFERENCES public.individuals(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: individual_additional_info fk_individual_additional_info_portfolio_file_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.individual_additional_info
    ADD CONSTRAINT fk_individual_additional_info_portfolio_file_id__id FOREIGN KEY (portfolio_file_id) REFERENCES public.uploaded_files_table(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: individual_additional_info fk_individual_additional_info_profile_picture_file_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.individual_additional_info
    ADD CONSTRAINT fk_individual_additional_info_profile_picture_file_id__id FOREIGN KEY (profile_picture_file_id) REFERENCES public.uploaded_files_table(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: individual_additional_values fk_individual_additional_values_additional_value_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.individual_additional_values
    ADD CONSTRAINT fk_individual_additional_values_additional_value_id__id FOREIGN KEY (additional_value_id) REFERENCES public.additional_value(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: individual_additional_values fk_individual_additional_values_individual_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.individual_additional_values
    ADD CONSTRAINT fk_individual_additional_values_individual_id__id FOREIGN KEY (individual_id) REFERENCES public.individuals(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: individuals_available_time_slots fk_individuals_available_time_slots_individual_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.individuals_available_time_slots
    ADD CONSTRAINT fk_individuals_available_time_slots_individual_id__id FOREIGN KEY (individual_id) REFERENCES public.experts(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: individuals fk_individuals_cv_file_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.individuals
    ADD CONSTRAINT fk_individuals_cv_file_id__id FOREIGN KEY (cv_file_id) REFERENCES public.uploaded_files_table(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: individuals fk_individuals_expert_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.individuals
    ADD CONSTRAINT fk_individuals_expert_id__id FOREIGN KEY (expert_id) REFERENCES public.experts(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: individuals fk_individuals_id_document_file_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.individuals
    ADD CONSTRAINT fk_individuals_id_document_file_id__id FOREIGN KEY (id_document_file_id) REFERENCES public.uploaded_files_table(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: internal_financial_accounts fk_internal_financial_accounts_account_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.internal_financial_accounts
    ADD CONSTRAINT fk_internal_financial_accounts_account_id__id FOREIGN KEY (account_id) REFERENCES public.financial_accounts(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: invoice_items fk_invoice_items_invoice_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.invoice_items
    ADD CONSTRAINT fk_invoice_items_invoice_id__id FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: invoice_items fk_invoice_items_template_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.invoice_items
    ADD CONSTRAINT fk_invoice_items_template_id__id FOREIGN KEY (template_id) REFERENCES public.billable_items(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: invoice_payments fk_invoice_payments_created_by__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.invoice_payments
    ADD CONSTRAINT fk_invoice_payments_created_by__id FOREIGN KEY (created_by) REFERENCES public.clients(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: invoice_payments fk_invoice_payments_deleted_by__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.invoice_payments
    ADD CONSTRAINT fk_invoice_payments_deleted_by__id FOREIGN KEY (deleted_by) REFERENCES public.clients(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: invoice_payments fk_invoice_payments_invoice_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.invoice_payments
    ADD CONSTRAINT fk_invoice_payments_invoice_id__id FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: invoices fk_invoices_client_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT fk_invoices_client_id__id FOREIGN KEY (client_id) REFERENCES public.clients(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: journal_entries fk_journal_entries_currency_account_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT fk_journal_entries_currency_account_id__id FOREIGN KEY (currency_account_id) REFERENCES public.financial_currency_accounts(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: journal_entries fk_journal_entries_transaction_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT fk_journal_entries_transaction_id__id FOREIGN KEY (transaction_id) REFERENCES public.journal_transactions(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: library_materials fk_library_materials_billable_item_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.library_materials
    ADD CONSTRAINT fk_library_materials_billable_item_id__id FOREIGN KEY (billable_item_id) REFERENCES public.billable_items(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: library_materials fk_library_materials_category_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.library_materials
    ADD CONSTRAINT fk_library_materials_category_id__id FOREIGN KEY (category_id) REFERENCES public.library_material_categories(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: library_materials fk_library_materials_file_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.library_materials
    ADD CONSTRAINT fk_library_materials_file_id__id FOREIGN KEY (file_id) REFERENCES public.uploaded_files_table(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: notifications fk_notifications_client_to_notify__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT fk_notifications_client_to_notify__id FOREIGN KEY (client_to_notify) REFERENCES public.clients(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: notifications_logs fk_notifications_logs_client_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.notifications_logs
    ADD CONSTRAINT fk_notifications_logs_client_id__id FOREIGN KEY (client_id) REFERENCES public.clients(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: notifications_logs fk_notifications_logs_notification_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.notifications_logs
    ADD CONSTRAINT fk_notifications_logs_notification_id__id FOREIGN KEY (notification_id) REFERENCES public.notifications(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: predefined_service_packages fk_predefined_service_packages_billable_item_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.predefined_service_packages
    ADD CONSTRAINT fk_predefined_service_packages_billable_item_id__id FOREIGN KEY (billable_item_id) REFERENCES public.billable_items(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: predefined_service_packages fk_predefined_service_packages_predefined_service_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.predefined_service_packages
    ADD CONSTRAINT fk_predefined_service_packages_predefined_service_id__id FOREIGN KEY (predefined_service_id) REFERENCES public.predefined_services(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: predefined_service_packages fk_predefined_service_packages_request_form_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.predefined_service_packages
    ADD CONSTRAINT fk_predefined_service_packages_request_form_id__id FOREIGN KEY (request_form_id) REFERENCES public.form_templates(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: predefined_service_request_log fk_predefined_service_request_log_expert_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.predefined_service_request_log
    ADD CONSTRAINT fk_predefined_service_request_log_expert_id__id FOREIGN KEY (expert_id) REFERENCES public.experts(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: predefined_service_request_log fk_predefined_service_request_log_request_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.predefined_service_request_log
    ADD CONSTRAINT fk_predefined_service_request_log_request_id__id FOREIGN KEY (request_id) REFERENCES public.predefined_service_requests(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: predefined_service_requests fk_predefined_service_requests_expert_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.predefined_service_requests
    ADD CONSTRAINT fk_predefined_service_requests_expert_id__id FOREIGN KEY (expert_id) REFERENCES public.experts(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: predefined_service_requests fk_predefined_service_requests_expert_rating_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.predefined_service_requests
    ADD CONSTRAINT fk_predefined_service_requests_expert_rating_id__id FOREIGN KEY (expert_rating_id) REFERENCES public.ratings(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: predefined_service_requests fk_predefined_service_requests_invoice_item_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.predefined_service_requests
    ADD CONSTRAINT fk_predefined_service_requests_invoice_item_id__id FOREIGN KEY (invoice_item_id) REFERENCES public.invoice_items(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: predefined_service_requests fk_predefined_service_requests_predefined_service_package_id__i; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.predefined_service_requests
    ADD CONSTRAINT fk_predefined_service_requests_predefined_service_package_id__i FOREIGN KEY (predefined_service_package_id) REFERENCES public.predefined_service_packages(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: predefined_service_requests fk_predefined_service_requests_recurring_of__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.predefined_service_requests
    ADD CONSTRAINT fk_predefined_service_requests_recurring_of__id FOREIGN KEY (recurring_of) REFERENCES public.predefined_service_requests(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: predefined_service_requests fk_predefined_service_requests_user_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.predefined_service_requests
    ADD CONSTRAINT fk_predefined_service_requests_user_id__id FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: predefined_service_requests fk_predefined_service_requests_user_rating_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.predefined_service_requests
    ADD CONSTRAINT fk_predefined_service_requests_user_rating_id__id FOREIGN KEY (user_rating_id) REFERENCES public.ratings(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: purchased_library_materials fk_purchased_library_materials_buyer_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.purchased_library_materials
    ADD CONSTRAINT fk_purchased_library_materials_buyer_id__id FOREIGN KEY (buyer_id) REFERENCES public.clients(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: purchased_library_materials fk_purchased_library_materials_invoice_item_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.purchased_library_materials
    ADD CONSTRAINT fk_purchased_library_materials_invoice_item_id__id FOREIGN KEY (invoice_item_id) REFERENCES public.invoice_items(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: purchased_library_materials fk_purchased_library_materials_material_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.purchased_library_materials
    ADD CONSTRAINT fk_purchased_library_materials_material_id__id FOREIGN KEY (material_id) REFERENCES public.library_materials(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: ratings fk_ratings_client_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.ratings
    ADD CONSTRAINT fk_ratings_client_id__id FOREIGN KEY (client_id) REFERENCES public.clients(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: ratings fk_ratings_rateable_item_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.ratings
    ADD CONSTRAINT fk_ratings_rateable_item_id__id FOREIGN KEY (rateable_item_id) REFERENCES public.ratable_items(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: user_business_details fk_user_business_details_business_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.user_business_details
    ADD CONSTRAINT fk_user_business_details_business_id__id FOREIGN KEY (business_id) REFERENCES public.user_businesses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: user_business_details fk_user_business_details_business_logo_file_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.user_business_details
    ADD CONSTRAINT fk_user_business_details_business_logo_file_id__id FOREIGN KEY (business_logo_file_id) REFERENCES public.uploaded_files_table(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: user_business_details fk_user_business_details_business_stage_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.user_business_details
    ADD CONSTRAINT fk_user_business_details_business_stage_id__id FOREIGN KEY (business_stage_id) REFERENCES public.user_business_stage(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: user_business_details fk_user_business_details_registration_type_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.user_business_details
    ADD CONSTRAINT fk_user_business_details_registration_type_id__id FOREIGN KEY (registration_type_id) REFERENCES public.business_registration_type(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: user_business_details fk_user_business_details_user_role_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.user_business_details
    ADD CONSTRAINT fk_user_business_details_user_role_id__id FOREIGN KEY (user_role_id) REFERENCES public.user_business_roles(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: user_business_industry fk_user_business_industry_business_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.user_business_industry
    ADD CONSTRAINT fk_user_business_industry_business_id__id FOREIGN KEY (business_id) REFERENCES public.user_businesses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: user_business_industry fk_user_business_industry_industry_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.user_business_industry
    ADD CONSTRAINT fk_user_business_industry_industry_id__id FOREIGN KEY (industry_id) REFERENCES public.business_industry(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: user_business_model fk_user_business_model_business_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.user_business_model
    ADD CONSTRAINT fk_user_business_model_business_id__id FOREIGN KEY (business_id) REFERENCES public.user_businesses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: user_business_model fk_user_business_model_model_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.user_business_model
    ADD CONSTRAINT fk_user_business_model_model_id__id FOREIGN KEY (model_id) REFERENCES public.business_model(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: user_business_operation_countries fk_user_business_operation_countries_business_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.user_business_operation_countries
    ADD CONSTRAINT fk_user_business_operation_countries_business_id__id FOREIGN KEY (business_id) REFERENCES public.user_businesses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: user_business_operation_countries fk_user_business_operation_countries_country_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.user_business_operation_countries
    ADD CONSTRAINT fk_user_business_operation_countries_country_id__id FOREIGN KEY (country_id) REFERENCES public.countries(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: user_business_operation_country_states fk_user_business_operation_country_states_country_state_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.user_business_operation_country_states
    ADD CONSTRAINT fk_user_business_operation_country_states_country_state_id__id FOREIGN KEY (country_state_id) REFERENCES public.country_states(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: user_business_operation_country_states fk_user_business_operation_country_states_operation_country_id_; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.user_business_operation_country_states
    ADD CONSTRAINT fk_user_business_operation_country_states_operation_country_id_ FOREIGN KEY (operation_country_id) REFERENCES public.user_business_operation_countries(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: user_business_registration_type fk_user_business_registration_type_business_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.user_business_registration_type
    ADD CONSTRAINT fk_user_business_registration_type_business_id__id FOREIGN KEY (business_id) REFERENCES public.user_businesses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: user_business_registration_type fk_user_business_registration_type_registration_type_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.user_business_registration_type
    ADD CONSTRAINT fk_user_business_registration_type_registration_type_id__id FOREIGN KEY (registration_type_id) REFERENCES public.user_business_registration_type(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: user_businesses fk_user_businesses_user_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.user_businesses
    ADD CONSTRAINT fk_user_businesses_user_id__id FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: user_living_location_countries fk_user_living_location_countries_country_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.user_living_location_countries
    ADD CONSTRAINT fk_user_living_location_countries_country_id__id FOREIGN KEY (country_id) REFERENCES public.countries(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: user_living_location_countries fk_user_living_location_countries_user_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.user_living_location_countries
    ADD CONSTRAINT fk_user_living_location_countries_user_id__id FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: user_living_location_country_states fk_user_living_location_country_states_country_state_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.user_living_location_country_states
    ADD CONSTRAINT fk_user_living_location_country_states_country_state_id__id FOREIGN KEY (country_state_id) REFERENCES public.country_states(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: user_living_location_country_states fk_user_living_location_country_states_living_location_country_; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.user_living_location_country_states
    ADD CONSTRAINT fk_user_living_location_country_states_living_location_country_ FOREIGN KEY (living_location_country_id) REFERENCES public.user_living_location_countries(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: user_profiles fk_user_profiles_current_work_status_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.user_profiles
    ADD CONSTRAINT fk_user_profiles_current_work_status_id__id FOREIGN KEY (current_work_status_id) REFERENCES public.user_current_work_statuses(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: user_profiles fk_user_profiles_user_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.user_profiles
    ADD CONSTRAINT fk_user_profiles_user_id__id FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: user_specializations fk_user_specializations_specialization_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.user_specializations
    ADD CONSTRAINT fk_user_specializations_specialization_id__id FOREIGN KEY (specialization_id) REFERENCES public.specializations(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: user_specializations fk_user_specializations_user_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.user_specializations
    ADD CONSTRAINT fk_user_specializations_user_id__id FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: users fk_users_client_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT fk_users_client_id__id FOREIGN KEY (client_id) REFERENCES public.clients(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: verifications fk_verifications_client_id__id; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.verifications
    ADD CONSTRAINT fk_verifications_client_id__id FOREIGN KEY (client_id) REFERENCES public.clients(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

